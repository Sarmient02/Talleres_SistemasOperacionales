#!/bin/bash

cd ../

tar -cvzf comprimido.tar.gz taller02/

mv comprimido.tar.gz taller02/

echo "La carpeta se ha comprimido en comprimido.tar.gz"
