#!/bin/bash
mkdir carpeta
cd carpeta
echo "1 2 3 4 5" > archivo1
echo "6 7 8 9 10" > archivo2
echo "Archivos creados exitosamente"
