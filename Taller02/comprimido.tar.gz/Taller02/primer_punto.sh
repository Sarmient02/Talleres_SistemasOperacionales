#!/bin/bash
mkdir carpeta

echo "1 2 3 4 5" > carpeta/archivo1
echo "6 7 8 9 10" > carpeta/archivo2

echo "Archivos creados exitosamente"
