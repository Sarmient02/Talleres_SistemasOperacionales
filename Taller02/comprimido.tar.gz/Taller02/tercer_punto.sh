#!/bin/bash

cd ../

tar -cvzf comprimido.tar.gz Taller02/

mv comprimido.tar.gz Taller02/

echo "La carpeta se ha comprimido en comprimido.tar.gz"
