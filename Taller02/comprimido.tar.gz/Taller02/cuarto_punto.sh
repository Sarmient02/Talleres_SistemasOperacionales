#!/bin/bash

source primer_punto.sh

source segundo_punto.sh

source tercer_punto.sh

echo "Scripts ejecutados exitosamente!"
